const user = require('./user');

module.exports = {
  userRoutes: user
}