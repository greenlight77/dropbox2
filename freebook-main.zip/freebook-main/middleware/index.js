const {userValidate} = require('./validator')

module.exports = {
  checkUserInput: userValidate
}