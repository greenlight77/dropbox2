const {userDetail} = require('./user')
module.exports = {
  saveUserDetail: userDetail
}