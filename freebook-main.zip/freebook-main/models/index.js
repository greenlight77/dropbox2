const User = require('./User')
module.exports = {
  UserData: User
}